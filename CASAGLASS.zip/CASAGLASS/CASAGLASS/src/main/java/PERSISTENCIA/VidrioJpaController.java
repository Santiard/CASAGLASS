/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package PERSISTENCIA;

import LOGICA.Vidrio;
import PERSISTENCIA.exceptions.NonexistentEntityException;
import PERSISTENCIA.exceptions.PreexistingEntityException;
import java.io.Serializable;
import java.util.List;
import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Query;
import javax.persistence.EntityNotFoundException;
import javax.persistence.Persistence;
import javax.persistence.criteria.CriteriaQuery;
import javax.persistence.criteria.Root;

/**
 *
 * @author usuario
 */
public class VidrioJpaController implements Serializable {

    public VidrioJpaController(EntityManagerFactory emf) {
        this.emf = emf;
    }
    
    public VidrioJpaController(){
    
        emf= Persistence.createEntityManagerFactory("BASEDEDATOSPU");
    
    }
    
    private EntityManagerFactory emf = null;

    public EntityManager getEntityManager() {
        return emf.createEntityManager();
    }

    public void create(Vidrio vidrio) throws PreexistingEntityException, Exception {
        EntityManager em = null;
        try {
            em = getEntityManager();
            em.getTransaction().begin();
            em.persist(vidrio);
            em.getTransaction().commit();
        } catch (Exception ex) {
            if (findVidrio(vidrio.getId()) != null) {
                throw new PreexistingEntityException("Vidrio " + vidrio + " already exists.", ex);
            }
            throw ex;
        } finally {
            if (em != null) {
                em.close();
            }
        }
    }

    public void edit(Vidrio vidrio) throws NonexistentEntityException, Exception {
        EntityManager em = null;
        try {
            em = getEntityManager();
            em.getTransaction().begin();
            vidrio = em.merge(vidrio);
            em.getTransaction().commit();
        } catch (Exception ex) {
            String msg = ex.getLocalizedMessage();
            if (msg == null || msg.length() == 0) {
                int id = vidrio.getId();
                if (findVidrio(id) == null) {
                    throw new NonexistentEntityException("The vidrio with id " + id + " no longer exists.");
                }
            }
            throw ex;
        } finally {
            if (em != null) {
                em.close();
            }
        }
    }

    public void destroy(int id) throws NonexistentEntityException {
        EntityManager em = null;
        try {
            em = getEntityManager();
            em.getTransaction().begin();
            Vidrio vidrio;
            try {
                vidrio = em.getReference(Vidrio.class, id);
                vidrio.getId();
            } catch (EntityNotFoundException enfe) {
                throw new NonexistentEntityException("The vidrio with id " + id + " no longer exists.", enfe);
            }
            em.remove(vidrio);
            em.getTransaction().commit();
        } finally {
            if (em != null) {
                em.close();
            }
        }
    }

    public List<Vidrio> findVidrioEntities() {
        return findVidrioEntities(true, -1, -1);
    }

    public List<Vidrio> findVidrioEntities(int maxResults, int firstResult) {
        return findVidrioEntities(false, maxResults, firstResult);
    }

    private List<Vidrio> findVidrioEntities(boolean all, int maxResults, int firstResult) {
        EntityManager em = getEntityManager();
        try {
            CriteriaQuery cq = em.getCriteriaBuilder().createQuery();
            cq.select(cq.from(Vidrio.class));
            Query q = em.createQuery(cq);
            if (!all) {
                q.setMaxResults(maxResults);
                q.setFirstResult(firstResult);
            }
            return q.getResultList();
        } finally {
            em.close();
        }
    }

    public Vidrio findVidrio(int id) {
        EntityManager em = getEntityManager();
        try {
            return em.find(Vidrio.class, id);
        } finally {
            em.close();
        }
    }

    public int getVidrioCount() {
        EntityManager em = getEntityManager();
        try {
            CriteriaQuery cq = em.getCriteriaBuilder().createQuery();
            Root<Vidrio> rt = cq.from(Vidrio.class);
            cq.select(em.getCriteriaBuilder().count(rt));
            Query q = em.createQuery(cq);
            return ((Long) q.getSingleResult()).intValue();
        } finally {
            em.close();
        }
    }
    
}
