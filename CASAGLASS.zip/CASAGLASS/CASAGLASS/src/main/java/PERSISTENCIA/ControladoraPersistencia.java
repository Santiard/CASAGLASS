
package PERSISTENCIA;

import LOGICA.Cliente;
import LOGICA.Producto;
import LOGICA.Vidrio;
import PERSISTENCIA.exceptions.NonexistentEntityException;
import java.util.ArrayList;
import java.util.List;
import java.util.logging.Level;
import java.util.logging.Logger;

public class ControladoraPersistencia {
    
    
    ClienteJpaController ClienteJpa = new ClienteJpaController();
    ProductoJpaController ProductoJpa = new ProductoJpaController();
    VidrioJpaController VidrioJpa = new VidrioJpaController();

    public void crearCliente(Cliente cli) {

        ClienteJpa.create(cli);
        
    }

    public void eliminarCliente(int id) {

        try {
            ClienteJpa.destroy(id);
        } catch (NonexistentEntityException ex) {
            Logger.getLogger(ControladoraPersistencia.class.getName()).log(Level.SEVERE, null, ex);
        }

    }

    public void editarCliente(Cliente cli) {

        try {
            ClienteJpa.edit(cli);
        } catch (Exception ex) {
            Logger.getLogger(ControladoraPersistencia.class.getName()).log(Level.SEVERE, null, ex);
        }
        
    }

    public Cliente traerCliente(int id) {

        return ClienteJpa.findCliente(id);
        
    }

    public ArrayList<Cliente> traerListaClientes() {

        List<Cliente> lista = ClienteJpa.findClienteEntities();
        ArrayList<Cliente> listaClientes = new ArrayList <Cliente> (lista);
        
        
        return listaClientes;
    }

    public void crearProducto(Producto pro) {
        try {
            ProductoJpa.create(pro);
        } catch (Exception ex) {
            Logger.getLogger(ControladoraPersistencia.class.getName()).log(Level.SEVERE, null, ex);
        }

    }

    public void eliminarProducto(String id) throws NonexistentEntityException {
        ProductoJpa.destroy(id);
    }

    public void editarProducto(Producto pro) {
        try {
            ProductoJpa.edit(pro);
        } catch (Exception ex) {
            Logger.getLogger(ControladoraPersistencia.class.getName()).log(Level.SEVERE, null, ex);
        }
    }

    public void traerProducto(String id) {
        ProductoJpa.findProducto(id);
    }

    public ArrayList<Producto> traerProductos() {
        List<Producto> lista = ProductoJpa.findProductoEntities();
        ArrayList<Producto> listaProductos = new ArrayList <Producto>(lista);
        
        return listaProductos;
    }

    public void crearVidrio(Vidrio vi) {
        
        try {
            VidrioJpa.create(vi);
        } catch (Exception ex) {
            Logger.getLogger(ControladoraPersistencia.class.getName()).log(Level.SEVERE, null, ex);
        }
        
    }

    public void eliminarVidrio(int id) {
        try {
            VidrioJpa.destroy(id);
        } catch (NonexistentEntityException ex) {
            Logger.getLogger(ControladoraPersistencia.class.getName()).log(Level.SEVERE, null, ex);
        }
    }

    public void editarVidrio(Vidrio vi) {
        try {
            VidrioJpa.edit(vi);
        } catch (Exception ex) {
            Logger.getLogger(ControladoraPersistencia.class.getName()).log(Level.SEVERE, null, ex);
        }
    }

    public void traerVidrio(int id) {
        VidrioJpa.findVidrio(id);
    }

    public ArrayList<Vidrio> traerVidrios() {
        List<Vidrio> lista = VidrioJpa.findVidrioEntities();
        ArrayList<Vidrio> listaVidrios= new ArrayList<Vidrio>(lista);
        return listaVidrios;
    }
}
