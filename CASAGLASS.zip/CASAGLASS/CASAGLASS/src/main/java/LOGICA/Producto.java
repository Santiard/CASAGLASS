
package LOGICA;

import java.io.Serializable;
import javax.persistence.Entity;
import javax.persistence.Id;

@Entity
public class Producto implements Serializable {
   
    
    @Id
    private String codigo;
    private String categoria;
    private String nombre;
    private String color;
    private String tipo;
    private int cantidad;
    private float costo;
    private float precioInsula;
    private float precioCentro;
    private float precioPatios;
    private float precioEspecial;

    public Producto() {
    }

    public Producto(String codigo,String categoria, String nombre, String color, String tipo, int cantidad, float costo, float precioInsula, float precioCentro, float precioPatios, float precioEspecial) {
        this.codigo = codigo;
        this.categoria=categoria;
        this.nombre = nombre;
        this.color = color;
        this.tipo = tipo;
        this.cantidad = cantidad;
        this.costo = costo;
        this.precioInsula = precioInsula;
        this.precioCentro = precioCentro;
        this.precioPatios = precioPatios;
        this.precioEspecial = precioEspecial;
    }

    public String getCategoria() {
        return categoria;
    }

    
    public String getCodigo() {
        return codigo;
    }

    public String getNombre() {
        return nombre;
    }

    public String getColor() {
        return color;
    }

    public String getTipo() {
        return tipo;
    }

    public int getCantidad() {
        return cantidad;
    }

    public float getCosto() {
        return costo;
    }

    public float getPrecioInsula() {
        return precioInsula;
    }

    public float getPrecioCentro() {
        return precioCentro;
    }

    public float getPrecioPatios() {
        return precioPatios;
    }

    public float getPrecioEspecial() {
        return precioEspecial;
    }

    public void setCodigo(String codigo) {
        this.codigo = codigo;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public void setColor(String color) {
        this.color = color;
    }

    public void setTipo(String tipo) {
        this.tipo = tipo;
    }

    public void setCantidad(int cantidad) {
        this.cantidad = cantidad;
    }

    public void setCosto(float costo) {
        this.costo = costo;
    }

    public void setPrecioInsula(float precioInsula) {
        this.precioInsula = precioInsula;
    }

    public void setPrecioCentro(float precioCentro) {
        this.precioCentro = precioCentro;
    }

    public void setPrecioPatios(float precioPatios) {
        this.precioPatios = precioPatios;
    }

    public void setPrecioEspecial(float precioEspecial) {
        this.precioEspecial = precioEspecial;
    }

    public void setCategoria(String categoria) {
        this.categoria = categoria;
    }
    
    
}
