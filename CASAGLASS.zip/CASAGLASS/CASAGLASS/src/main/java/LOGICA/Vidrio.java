
package LOGICA;

import java.io.Serializable;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
@Entity
public class Vidrio implements Serializable {
    
    @Id
    @GeneratedValue(strategy=GenerationType.SEQUENCE)
    private int id;
    private String nombre;
    private float mm;
    private float m1;
    private float m2;
    private float laminas;
    private float costo;
    private float precioVenta;
    private float precioEspecial;

    public Vidrio() {
    }
    
    public Vidrio(int id, String nombre, float mm, float m1, float m2, float laminas, float costo, float precioVenta, float precioEspecial) {
        this.id = id;
        this.nombre = nombre;
        this.mm = mm;
        this.m1 = m1;
        this.m2 = m2;
        this.laminas = laminas;
        this.costo = costo;
        this.precioVenta = precioVenta;
        this.precioEspecial = precioEspecial;
    }

    public int getId() {
        return id;
    }

    public String getNombre() {
        return nombre;
    }

    public float getMm() {
        return mm;
    }

    public float getM1() {
        return m1;
    }

    public float getM2() {
        return m2;
    }

    public float getLaminas() {
        return laminas;
    }

    public float getCosto() {
        return costo;
    }

    public float getPrecioVenta() {
        return precioVenta;
    }

    public float getPrecioEspecial() {
        return precioEspecial;
    }

    public void setId(int id) {
        this.id = id;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public void setMm(float mm) {
        this.mm = mm;
    }

    public void setM1(float m1) {
        this.m1 = m1;
    }

    public void setM2(float m2) {
        this.m2 = m2;
    }

    public void setLaminas(float laminas) {
        this.laminas = laminas;
    }

    public void setCosto(float costo) {
        this.costo = costo;
    }

    public void setPrecioVenta(float precioVenta) {
        this.precioVenta = precioVenta;
    }

    public void setPrecioEspecial(float precioEspecial) {
        this.precioEspecial = precioEspecial;
    }

    
    
    
    
    
}
