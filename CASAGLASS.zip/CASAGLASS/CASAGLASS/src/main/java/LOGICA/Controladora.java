
package LOGICA;

import PERSISTENCIA.ControladoraPersistencia;
import PERSISTENCIA.exceptions.NonexistentEntityException;
import java.util.ArrayList;

public class Controladora {
    
    ControladoraPersistencia controlPersis = new ControladoraPersistencia();
    
    
    
    
    public int convertirStringAInt(String numeroString) {
       
        String texto = numeroString;
        int numero = Integer.parseInt(texto);
        return numero;
    }
    
    public String convertirIntAString(int numeroInt) {       

        String texto = String.valueOf(numeroInt);
        
        return texto;
    }
    
    public String convertirFloatAString(float numeroFloat) {

        String texto = Float.toString(numeroFloat);

        return texto;
    }
    
    
    public Vidrio ordenarVidrio(int id, String nombre, float mm, float m1, float m2, float laminas, float costo, float precioVenta, float precioEspecial){
        Vidrio vi= new Vidrio(id,nombre,mm,m1,m2,laminas,costo,precioVenta,precioEspecial);
        return vi;
    
    }
    public void crearVidrio(Vidrio vi){
        controlPersis.crearVidrio(vi);
    }
    
    public void eliminarVidrio(int id){
        controlPersis.eliminarVidrio(id);        
    }
    public void editarVidrio(Vidrio vi){
        controlPersis.editarVidrio(vi);
    }
    public void traeVidrio(int id){
        controlPersis.traerVidrio(id);
    }
    public ArrayList<Vidrio> traerVidrios(){
        return controlPersis.traerVidrios();
    }
    
    
    
    public Producto ordenarProducto(String codigo,String categoria, String nombre, String color, String tipo, int cantidad, float costo, float precioInsula, float precioCentro, float precioPatios, float precioEspecial){
    
        Producto pro = new Producto (codigo,categoria,nombre,color,tipo,cantidad,costo,precioInsula,precioCentro,precioPatios,precioEspecial);
        return pro;
        
    }
    
    public void crearProducto(Producto pro){
        controlPersis.crearProducto(pro);
    }
    
    public void eliminarProducto(String id) throws NonexistentEntityException{
        controlPersis.eliminarProducto(id);
    }
    
    public void editarProducto(Producto pro){
        controlPersis.editarProducto(pro);
    }
    
    public void traerProducto(String id){
        controlPersis.traerProducto(id);
    }
    
    public ArrayList<Producto> traerProductos(){
        return controlPersis.traerProductos();
    }
    
    public Cliente ordenarCliente(int id,String nit,String nombre,String direccion,String telefono,String ciudad,String correo){
    
        Cliente cli = new Cliente (id,nit,nombre,direccion,telefono,ciudad,correo);
        return cli;
    }
    public void crearCliente(Cliente cli){
    controlPersis.crearCliente(cli);
    }
    
    public void eliminarCliente(int id){
    controlPersis.eliminarCliente(id);}
    
    public void editarCliente(Cliente cli){
    
     controlPersis.editarCliente(cli); 
    
    }
    
    public Cliente traerCliente(int id){
    
    
    
        return controlPersis.traerCliente(id);
    }
    
    public ArrayList<Cliente> traerListaClientes (){
    
        return controlPersis.traerListaClientes();
    }
    
    
}
